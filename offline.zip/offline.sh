#!/bin/bash
set -e

warning() { echo -e "\033[31m\033[01m$*\033[0m"; }         # 红色
error() { echo -e "\033[31m\033[01m$*\033[0m" && exit 1; } # 红色
info() { echo -e "\033[32m\033[01m$*\033[0m"; }            # 绿色
hint() { echo -e "\033[33m\033[01m$*\033[0m"; }            # 黄色

echo_uninstall() {
    echo "systemctl disable --now $1 ; rm -rf /opt/$1 ; rm -f /etc/systemd/system/$1.service"
}

# 开始

[ -f /tmp/nyanpass/info.txt ] || error "未正确解包"

cd /tmp/nyanpass

info "==== 离线包版本信息 ===="

cat info.txt

info "==== 请输入服务名 ===="

# shellcheck disable=SC2162
read -p "请输入服务名 [默认 nyanpass] : " service_name
service_name=$(echo "$service_name" | awk '{print$1}')
if [ -z "$service_name" ]; then
    service_name="nyanpass"
fi
if [ -f "/etc/systemd/system/${service_name}.service" ]; then
    hint "该服务已经存在，请先运行以下命令卸载："
    echo_uninstall "$service_name"
    exit
fi

info "==== 正在安装文件 ===="

mkdir -p /opt/"$service_name"/
cp -r /tmp/nyanpass/* /opt/"$service_name"/
rm -f /opt/"$service_name"/*.sh

export NO_DOWNLOAD=1
export S=$service_name
bash nyanpass-install.sh rel_nodeclient "$1"

rm -rf /tmp/nyanpass
